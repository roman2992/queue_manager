from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.dependencies import current_user, require_admin
from app.core.database import get_db
from app.core.security import hash_password, verify_password, create_access_token
from app.models import User, Business, Service, Queue, Ticket, TicketStatus, Role

router=APIRouter()
class AuthIn(BaseModel): phone:str; password:str=Field(min_length=6); role:Role=Role.CUSTOMER
class BusinessIn(BaseModel): name:str; address:str|None=None; latitude:float|None=None; longitude:float|None=None
class ServiceIn(BaseModel): name:str; avg_duration_minutes:int=30
class TicketOut(BaseModel): id:int; queue_sequence:int; status:str; people_ahead:int; expires_at:datetime|None

@router.post("/auth/register")
async def register(data:AuthIn, db:AsyncSession=Depends(get_db)):
    if await db.scalar(select(User).where(User.phone==data.phone)): raise HTTPException(409,"Phone already registered")
    user=User(phone=data.phone,password_hash=hash_password(data.password),role=data.role.value); db.add(user); await db.commit(); await db.refresh(user)
    return {"access_token":create_access_token(str(user.id),user.role),"user_id":user.id,"role":user.role}

@router.post("/auth/login")
async def login(data:AuthIn, db:AsyncSession=Depends(get_db)):
    user=await db.scalar(select(User).where(User.phone==data.phone))
    if not user or not verify_password(data.password,user.password_hash): raise HTTPException(401,"Invalid credentials")
    return {"access_token":create_access_token(str(user.id),user.role),"user_id":user.id,"role":user.role}

@router.post("/admin/businesses")
async def create_business(data:BusinessIn,user=Depends(require_admin),db:AsyncSession=Depends(get_db)):
    b=Business(owner_id=user.id,**data.model_dump()); db.add(b); await db.commit(); await db.refresh(b); return b

@router.post("/admin/businesses/{business_id}/services")
async def create_service(business_id:int,data:ServiceIn,user=Depends(require_admin),db:AsyncSession=Depends(get_db)):
    b=await db.scalar(select(Business).where(Business.id==business_id,Business.owner_id==user.id))
    if not b: raise HTTPException(404,"Business not found")
    s=Service(business_id=business_id,**data.model_dump()); db.add(s); await db.commit(); await db.refresh(s)
    q=Queue(service_id=s.id,name=s.name); db.add(q); await db.commit(); await db.refresh(q)
    return {"service":s,"queue":q}

@router.get("/businesses")
async def businesses(db:AsyncSession=Depends(get_db)): return (await db.scalars(select(Business))).all()

@router.post("/queues/{queue_id}/tickets",response_model=TicketOut)
async def join_queue(queue_id:int,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    q=await db.scalar(select(Queue).where(Queue.id==queue_id).with_for_update())
    if not q or not q.is_open: raise HTTPException(400,"Queue is closed")
    existing=await db.scalar(select(Ticket).where(Ticket.queue_id==queue_id,Ticket.user_id==user.id,Ticket.status.in_([s.value for s in TicketStatus if s in {TicketStatus.WAITING,TicketStatus.CHECKED_IN,TicketStatus.CALLED,TicketStatus.IN_SERVICE}])))
    if existing: raise HTTPException(409,"Already in queue")
    seq=q.next_sequence; q.next_sequence+=1
    t = Ticket(
        queue_id=queue_id,
        user_id=user.id,
        queue_sequence=seq,
        expires_at=None,
    )
    db.add(t)
    await db.commit()
    await db.refresh(t)
    ahead=await db.scalar(select(func.count()).select_from(Ticket).where(Ticket.queue_id==queue_id,Ticket.queue_sequence<seq,Ticket.status.in_([s.value for s in [TicketStatus.WAITING,TicketStatus.CHECKED_IN,TicketStatus.CALLED,TicketStatus.IN_SERVICE]])))
    return TicketOut(id=t.id,queue_sequence=seq,status=t.status,people_ahead=ahead or 0,expires_at=t.expires_at)

@router.get("/tickets/{ticket_id}",response_model=TicketOut)
async def ticket(ticket_id:int,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=await db.scalar(select(Ticket).where(Ticket.id==ticket_id,Ticket.user_id==user.id))
    if not t: raise HTTPException(404,"Ticket not found")
    ahead=await db.scalar(select(func.count()).select_from(Ticket).where(Ticket.queue_id==t.queue_id,Ticket.queue_sequence<t.queue_sequence,Ticket.status.in_([x.value for x in [TicketStatus.WAITING,TicketStatus.CHECKED_IN,TicketStatus.CALLED,TicketStatus.IN_SERVICE]])))
    return TicketOut(id=t.id,queue_sequence=t.queue_sequence,status=t.status,people_ahead=ahead or 0,expires_at=t.expires_at)

@router.post("/tickets/{ticket_id}/check-in",response_model=TicketOut)
async def check_in(ticket_id:int,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=await db.scalar(select(Ticket).where(Ticket.id==ticket_id,Ticket.user_id==user.id).with_for_update())
    if not t: raise HTTPException(404,"Ticket not found")
    if t.status != TicketStatus.WAITING.value: raise HTTPException(400,"Ticket cannot be checked in")
    t.status=TicketStatus.CHECKED_IN.value; t.check_in_at=datetime.now(timezone.utc); await db.commit(); await db.refresh(t)
    ahead=await db.scalar(select(func.count()).select_from(Ticket).where(Ticket.queue_id==t.queue_id,Ticket.queue_sequence<t.queue_sequence,Ticket.status.in_([x.value for x in [TicketStatus.WAITING,TicketStatus.CHECKED_IN,TicketStatus.CALLED,TicketStatus.IN_SERVICE]])))
    return TicketOut(id=t.id,queue_sequence=t.queue_sequence,status=t.status,people_ahead=ahead or 0,expires_at=t.expires_at)

async def _owned_queue(queue_id:int,user,db):
    q=await db.scalar(select(Queue).join(Service,Queue.service_id==Service.id).join(Business,Business.id==Service.business_id).where(Queue.id==queue_id,Business.owner_id==user.id))
    if not q: raise HTTPException(404,"Queue not found")
    return q

@router.get("/admin/queues/{queue_id}")
async def admin_queue(queue_id:int,user=Depends(require_admin),db:AsyncSession=Depends(get_db)):
    q=await _owned_queue(queue_id,user,db)
    rows=(await db.scalars(select(Ticket).where(Ticket.queue_id==q.id).order_by(Ticket.queue_sequence))).all()
    return [{"id":t.id,"sequence":t.queue_sequence,"status":t.status,"expires_at":t.expires_at} for t in rows]

@router.post("/admin/queues/{queue_id}/call-next")
async def call_next(queue_id:int,user=Depends(require_admin),db:AsyncSession=Depends(get_db)):
    q=await _owned_queue(queue_id,user,db)
    t=await db.scalar(select(Ticket).where(Ticket.queue_id==q.id,Ticket.status.in_([TicketStatus.WAITING.value,TicketStatus.CHECKED_IN.value])).order_by(Ticket.queue_sequence).with_for_update(skip_locked=True))
    if not t: raise HTTPException(409,"No waiting tickets")
    # t.status=TicketStatus.CALLED.value; t.called_at=datetime.now(timezone.utc); await db.commit(); return {"ticket_id":t.id,"sequence":t.queue_sequence,"status":t.status}
    now = datetime.now(timezone.utc)
    t.status = TicketStatus.CALLED.value
    t.called_at = now
    t.expires_at = now + timedelta(hours=2)

    await db.commit()

    return {
        "ticket_id": t.id,
        "sequence": t.queue_sequence,
        "status": t.status,
    }


@router.post("/admin/tickets/{ticket_id}/start")
async def start_ticket(ticket_id:int,user=Depends(require_admin),db:AsyncSession=Depends(get_db)):
    t=await db.scalar(select(Ticket).join(Queue,Ticket.queue_id==Queue.id).join(Service,Queue.service_id==Service.id).join(Business,Business.id==Service.business_id).where(Ticket.id==ticket_id,Business.owner_id==user.id).with_for_update())
    if not t or t.status != TicketStatus.CALLED.value: raise HTTPException(400,"Ticket cannot be started")
    t.status=TicketStatus.IN_SERVICE.value; t.service_started_at=datetime.now(timezone.utc); await db.commit(); return {"ticket_id":t.id,"status":t.status}

@router.post("/admin/tickets/{ticket_id}/complete")
async def complete_ticket(ticket_id:int,user=Depends(require_admin),db:AsyncSession=Depends(get_db)):
    t=await db.scalar(select(Ticket).join(Queue,Ticket.queue_id==Queue.id).join(Service,Queue.service_id==Service.id).join(Business,Business.id==Service.business_id).where(Ticket.id==ticket_id,Business.owner_id==user.id).with_for_update())
    if not t or t.status != TicketStatus.IN_SERVICE.value: raise HTTPException(400,"Ticket cannot be completed")
    now=datetime.now(timezone.utc); t.status=TicketStatus.COMPLETED.value; t.completed_at=now; t.resolved_at=now; t.resolved_reason="COMPLETED"; await db.commit(); return {"ticket_id":t.id,"status":t.status,"resolved_at":t.resolved_at}
