from datetime import datetime, timezone

from sqlalchemy import select

from app.core.database import SessionLocal
from app.models import Ticket, TicketStatus


async def expire_due_tickets():
    async with SessionLocal() as db:
        now = datetime.now(timezone.utc)

        rows = (
            await db.scalars(
                select(Ticket).where(
                    Ticket.expires_at <= now,
                    Ticket.status == TicketStatus.CALLED.value,
                )
            )
        ).all()

        for ticket in rows:
            ticket.status = TicketStatus.EXPIRED.value
            ticket.resolved_at = now
            ticket.resolved_reason = "TTL"

        await db.commit()

        return len(rows)